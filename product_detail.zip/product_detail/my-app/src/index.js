

import React from "react";
import ReactDOM  from "react-dom";
import App from './component/App';
import Login from "./component/Login";
import Add from "./component/Add";
import Show from "./component/Show";
import Update from "./component/Update";
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.bundle.js'


import {
    createBrowserRouter,
    RouterProvider,
  } from "react-router-dom";

  const  routerExample= createBrowserRouter([{
    path:"/",
    element:<App/>,
    children:[
        {path:"",element:<Login /> },
        {path:"add",element:<Add/> },
        {path:"show",element:<Show/> },
        {path:"update",element:<Update/> },
    ]
}]);

const root=ReactDOM.createRoot(document.getElementById('root'));
// root.render(<Login/>);
root.render(<RouterProvider router={routerExample}></RouterProvider>);


