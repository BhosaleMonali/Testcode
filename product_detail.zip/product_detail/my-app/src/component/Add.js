import React, { useRef } from 'react'
// "empid":107,
//  "name":"Monika",
//  "password":"monika@1",
//  "deptid": 40,

//  "salary":30000
// {
//     "customerId": "CU301",
//     "password": "PWD301",
//     "email": "cu301@met.edu",
//     "credit": 1000
// }

export default function Add() {
    var x1 = useRef();
    var x2 = useRef();
    var x3 = useRef();
    var x4 = useRef();
 
    function myfunc() {
       // alert('Welcome');
         // console.log(x1);
           //console.log(x2);
           //console.log(x3);

        var dataToStore = {

            customerId: x1.current.value,
            password: x2.current.value,
            email: x3.current.value,
            credit: x4.current.value

        }
        console.log(dataToStore);
        http://localhost:9004/onlineshop/customer
        fetch('http://localhost:9004/onlineshop/customer', {
            method: 'POST',
            body: JSON.stringify(dataToStore),
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(res => {
                console.log("res from Java Backend");
                console.log(res);
            })
            .catch(err => {
                console.log(err);
            });

    }

    return (
        <div className='container'>
            <form class="row g-3">
                <div class="col-lg-12">

                    <label for="inputEmail4" class="form-label">CustomerNo</label>
                    <input ref={x1} type="email" class="form-control" id="inputEmail4" />
                </div>
                <div class="col-lg-12">

                    <label for="inputEmail4" class="form-label">password</label>
                    <input ref={x2} type="password" class="form-control" id="inputEmail4" />
                </div>
                <div class="col-lg-12">
                    <label for="inputPassword4" class="form-label">email</label>
                    <input ref={x3} type="email" class="form-control" id="inputPassword4" />
                </div>


                <div class="col-lg-12">
                    <label for="inputAddress2" class="form-label">credit</label>
                    <input ref={x4} type="text" class="form-control" id="inputAddress2" placeholder="20000" />
                </div>

           


                <div class="col-lg-2">
                    <button onClick={myfunc} type="submit" class="btn btn-secondary">Submit</button>
                </div>
            </form>


        </div>
    )
}
