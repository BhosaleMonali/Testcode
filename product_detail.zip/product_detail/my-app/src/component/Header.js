import React from "react";
import { Link }from "react-router-dom"

// functional components also calles stateless
function Header() {
    return (
        <nav class="container  navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid ">
            <div class="logo">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_k3KVpOVNZUPxV1tfLiNPlWt2vDUvVb6bYQ&usqp=CAU" alt=""/>
                 </div>
                <a class="navbar-brand" href="#"> <b>MB Management </b></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <Link class="nav-link active" aria-current="page" to="/">Login</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/add">Add</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/show">CustomerDetail</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/update">ProductUpdate</Link>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Dropdown
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Setting</a></li>
                                
                            </ul>
                        </li>
                       
                    </ul>
                    <form class="d-flex" role="search">
                        <input  id="dept" class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
    )

}
export default Header;