import React,{useState,useRef,useEffect} from 'react'
import "./show.css";

export default function Update() {

    var[apidata , setApidata] = useState([])

        useEffect(()=>{
                    fetch('http://localhost:9004/onlineshop/product')
                    .then(res=>res.json())
                    .then(value=>{
                        console.log(value);
                        setApidata(value);
                        
                    })



    },[]);
    // }



  return (
    <div>
        <h1 class="text-center"> Product Data</h1> 
       <table className='table'>
        <thead>
        <th>PrductNo</th>
        <th>Stock</th>
        <th>price</th>
        </thead>
       
       <tbody>
            { 
        //         "productNo": 301,
        // "stock": 95,
        // "price": 550.65

                apidata && apidata.map(value=>
                    <tr>
                        <td>{value.productNo}</td>
                        <td>{value.stock}</td>
                        <td>{value.price}</td>
                       
                       

                    </tr>
                    
                    
                    )
            }
            </tbody>
        </table>

        
    </div>
  )
}
