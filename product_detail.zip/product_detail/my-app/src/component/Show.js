import React,{useState,useEffect} from 'react'
import "./show.css";

export default function Show() {

    var[apidata , setApidata] = useState([])
    //     useEffect(()=>{
    //                 fetch('http://localhost:9004/onlineshop/customer')
    //                 .then(res=>res.json())
    //                 .then(value=>{
    //                     console.log(value);
    //                     setApidata(value);                     
    //                 })
    // },[]);
    // // }
    useEffect(() => {
      fetch('http://localhost:9004/onlineshop/customer')
        .then(res => {
          if (!res.ok) {
            throw new Error(`HTTP error! Status: ${res.status}`);
          }
          return res.json();
        })
        .then(data => {
          console.log(data);
          setApidata(data);
        })
        .catch(error => {
          console.error('Fetch error:', error);
        });
    }, []);



  return (
    <div>
        <h1 class="text-center">Customer  Data</h1> 
        <table className="table">
          <thead>
              <tr>
                  <th>CustomerId</th>
                  <th>password</th>
                  <th>email</th>
                  <th>credit</th>
                  </tr>
            </thead>
        <tbody>            {
                 
                apidata && apidata.map(value=>
                  
              

                    <tr class="table-active">
                        <td>{value.customerId}</td>
                        <td>{value.password}</td>
                        <td>{value.email}</td>
                        <td>{value.credit}</td>
                    </tr>
                                        )
            }
            </tbody>

        </table>

        
    </div>
  )
}
