step 1: on terminal 
         a)npx create-react-app my-app
        b)npm start
        react default port no:3000