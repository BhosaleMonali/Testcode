//in redux/categorySlice.js
//here  we will create reducer
import { createSlice } from '@reduxjs/toolkit'

export const categorySlice = createSlice({
  name: 'category',
  initialState: {
    value: "12",
  },
  reducers: {
    DataTransfer:(state,actions)=>{
        console.log('dataTransfer Called');
        console.log(actions.payload); //getting the data from leftsection
        state.value = actions.payload;
    }
    
  },
});

// Action creators are generated for each case reducer function
export const { DataTransfer } = categorySlice.actions

export default categorySlice.reducer