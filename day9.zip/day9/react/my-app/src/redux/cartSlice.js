//in redux/categorySlice.js
//here  we will create reducer
import { createSlice } from '@reduxjs/toolkit'

export const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    value: ['perfume','wathces'],
  },
  reducers: {
    DataTransfer:(state)=>{
        console.log('cart reducer  Called');
    }
    
  },
});

// Action creators are generated for each case reducer function
export const { DataTransfer } = cartSlice.actions

export default cartSlice.reducer