import React from 'react';

var record=React.createContext();
export default record;
 
