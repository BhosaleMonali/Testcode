import React from 'react'
import { useDispatch } from 'react-redux'// step1 left side data stored  into redux store 
import { DataTransfer } from '../redux/categorySlice'; //step3
export default function Left(props) {
    const dispatch = useDispatch()  //step2:to create 
    
    var myfunc=(ev)=>{
        console.log('click working');
        // console.log(ev);
        // console.log(ev.target);
        console.log(ev.target.innerText);
        props.p1(ev.target.innerText);
        dispatch(DataTransfer(ev.target.innerText))//step4: sending the data from left to redux categorySlice
    }
  return (
    <div className='border border-1 p-3'>
    <ul>
        <li onClick={myfunc}>electonics</li>
        <li onClick={myfunc}>Jewellary</li>
        <li onClick={myfunc}>Clothes</li>
    </ul>
</div>
  
  )
}
