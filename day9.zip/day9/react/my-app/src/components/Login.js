import React,{useRef} from 'react'

export default function Login() {
//useref is used for the getting value of input box .It will work same as document.getElementbyvalue('x1').value;
    var x1=useRef();
    var x2=useRef();
    var x3=useRef();

    function myfunc(){
        // alert('Welcome');
    //    console.log(x1);
    //    console.log(x2);
    //    console.log(x3);
        var dataToStore ={
            // username: String,
            // userage: String,
            // userplace: String
            username: x1.current.value,
            userage:x2.current.value,
            userlocation:x3.current.value

        }
        console.log(dataToStore);
        fetch('http://localhost:9700/api/addUsers',{
            method:'POST',
            body:JSON.stringify(dataToStore),
            headers:{
                'Content-Type':'application/json'
            }
        })
        .then(res=>{
            console.log("res from Node js");
            console.log(res);
        })
        .catch(err=>{
            console.log(err);
        });

    }

  return (
    <div>
        <input ref={x1} type="text" placeholder='name'/><br/>
        <input ref={x2} type="text" placeholder='age'/><br/>
        <input ref={x3} type="text" placeholder='place'/><br/>
        {/* <input type='password' placeholder='a@b.com'/> */}
        {/* <br/> */}
        <button onClick={myfunc} className='btn btn-dark'>Login</button>
    </div>
  )
}
