import React from 'react'

export default function Product(props) {
    console.log(props);
  return (
    <div>
        <img src={props.path} classname='img-fluid' />
        <h2>{props.price}</h2>
        <p> {props.name}</p>
        <p>
            <button classname='btn btn-dark'>add to cart</button>
        </p>
    </div>
  )
}


