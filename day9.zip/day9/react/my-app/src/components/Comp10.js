import React, { Component } from 'react'
import Image from './Image'
import ErrorBoundary from '../ErrorBoundary'


export default class Comp10
    extends Component {
    render() {
        return (
            <div className='container'>
                <h1>Error Boundary Example</h1>
                <div className='row'>

                    <div className='col-4'>
                        <Image path="https://rukminim2.flixcart.com/image/312/312/l5jxt3k0/dslr-camera/m/n/a/-original-imagg7hsggshhwbz.jpeg?q=70" />
                    </div>

                    <div className='col-4'>
                        <Image path="https://rukminim2.flixcart.com/image/312/312/l5jxt3k0/dslr-camera/m/n/a/-original-imagg7hsggshhwbz.jpeg?q=70" />
                    </div>

                    <div className='col-4'>
                        <ErrorBoundary>
                        <Image path="" />
                        </ErrorBoundary>
                    </div>
                 


                </div>
            </div>
        )
    }
}
