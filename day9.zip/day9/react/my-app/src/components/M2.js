import React,{useState,useRef,useEffect} from 'react'

export default function M2(props){

    var[apidata , setApidata] = useState([])
    //once your page i.e. component is loaded
    //if there is change in any state variable 
   //useEffect with empty array will be called only once on page load
    useEffect(()=>{
        console.log('use effect called',Math.random());

        // fetch('http://localhost:9700/api/selectUsers')
        // .then(res=>{
        //     console.log(res);
        // })
        // .catch(err=>{
        //     console.log(err);
        // });

        fetch('http://localhost:9700/api/selectUsers')
        .then(res=>res.json())
        .then(value=>{
            console.log(value);
            setApidata(value);
            
        })



    },[]);

    var x1 = useRef();
    console.log(props);

    function myfunc(){
        props.age=23;
    }
   
    //state variable ,its a changeable variable within a functional component
    //var[variablename] = useState(initial value)
    var[counter,setCount]=useState(10);
//var[state variable,dispatcher function]=usestate(initial value)
    function f1(){
        setCount(counter+1);
        
    }
    function f2(){
        setCount(counter-1);
        
    }
    function p1(){
        console.log(x1);
        x1.current.innerHTML ="MET Cdac Mumbai";
        x1.current.style.background = 'rgb(255,0,0)';
    }


    return(
        <div>
            <h3>M2 Functional Component</h3>
            <p>Props Value:{props.name},{props.age}</p>
            <button onClick={myfunc}>Enter</button>
        <hr/>
            <button onClick={f1}>+</button>
            <button onClick={f2}>-</button>
            <p>state value:{counter}</p>  
        <hr/>
         <button onClick={p1}>Change</button>
         <p ref={x1}>Hello World</p>    
        <hr/>
        <table className='table'>
            {
                apidata && apidata.map(value=>
                    <tr>
                        <td>{value.username}</td>
                        <td>{value.userage}</td>
                        <td>{value.userlocation}</td>

                    </tr>
                    
                    
                    )
            }
        </table>
        </div>
    )
}