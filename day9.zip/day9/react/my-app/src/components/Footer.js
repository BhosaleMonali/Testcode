import React from "react";

// functional components also calles stateless
function Footer(){
    return(
        <div class="container text-center"> 
            <p className="footer">&copy; MET CDAC Sept2023 Batch</p>
        </div>
        
    )

}
export default Footer;