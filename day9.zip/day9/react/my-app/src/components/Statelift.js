import React, { useState } from 'react'
import Left from './Left'
import Right from './Right'

export default function Statelift() {
    var[cat,setCat] = useState("");
    function parentFunction(lidata){
        console.log('parent function',lidata);
        setCat(lidata);
    }
  return (
    <div className='container border border-1 p-3'>
        <h1>State Lift Example,{cat}</h1>
        <div className='row'>
            <div className='col-3'>
      
            <Left p1={parentFunction}/>
            </div>
            <div className='col-9'>
            <Right p2={cat}/>
                
            </div>

        </div>

    </div>
  )
}
