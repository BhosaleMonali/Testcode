import React,{useContext} from 'react'
import Compd from './Compd'
import Record from '../Contextapi'
export default function Compc(props) {
    var ans=useContext(Record);
  return (
    <div>
<h1> Comp C ,{ans}</h1>
        <hr/>
   <Compd p3={props.p2} />
    </div>
  )
}