import React from 'react'
import Compb from './Compb'
import Record from '../Contextapi'
export default function Compa() {
  return (
    <div className='container'>
        <h1> Comp A</h1>
        <hr/>
        <Record.Provider value="shirt">
        <Compb p1="New Clothes"/>
        </Record.Provider>

    
    
    
    </div>
  )
}
