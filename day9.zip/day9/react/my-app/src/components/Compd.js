import React, { useContext } from 'react'
import Record from '../Contextapi'

export default function Compd(props) {
    var result=useContext(Record);
  return (
    <div>
       <h1> Comp D</h1> 
       <hr/>
        <p>From Comp A using props Drilling:{props.p3}</p>
        <p>From Comp A using Context api :{result}</p>
        </div>
  )
}
