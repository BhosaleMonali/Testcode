import React from 'react'

class M1 extends React.Component{
    constructor(){
        super();
        console.log(this);
        this.state = {
            count:10,
            name:"Tejal"
        }

        //;lets initialize reference variable
    this.x1 = React.createRef();

    }


    f1(){
        this.setState({
            count:this.state.count+2,
            name:"Tejal Dhoble"
        })
    }
    f2(){
        this.setState({
            count:this.state.count-2,
            name:"Monali Bhosale" 
        })
    }
    f3(){
        console.log(this.x1);//current (p tag)
        this.x1.current.innerHTML ="Some Data";
        this.x1.current.style.background ='#e1b2d3';
    }
    //useEffect(()=>{},[])
    //only called once
    componentDidMount(){
        console.log('did mount',Math.random());
        fetch('http://localhost:9700/api/selectUsers')
        .then(res=>res.json())
        .then(value=>{
            console.log(value);
            // setApidata(value);
            
        })
    }
    //every time use update the count
    //useEffect(()=>{})
    componentDidUpdate(){
        console.log('did update',Math.random());
    }
    myfunc(){
        this.props.age=31;
    }
    render(){
        return (
            //react fragmentation tag is <> </> it is allow multiple tag line 
            <>
            <h3>M1 Class Component</h3>
            <p>Props Value:
                {this.props.name}
                {this.props.age}
            </p>
            <button onClick={this.myfunc}>Enter</button>
            <hr/>
            <button onClick={()=>{this.f1()}}>+</button>
            <button onClick={()=>{this.f2()}}>-</button> 
            <p>State values Are:
                {this.state.count},
                {this.state.name}</p> 
                <hr/>
                <button  onClick={()=>{this.f3()}}>Change</button>  
                <p ref={this.x1}>Hello World</p>        
            </>
        )
    }

}

export default M1;