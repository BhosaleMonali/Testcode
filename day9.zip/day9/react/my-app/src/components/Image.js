import React, { Component } from 'react'

export default class Image extends Component {
  render() {
    if(this.props.path == ""){
        throw new Error('Image Not Found');
    }
    return (
      <div>
   <img src={this.props.path} classname='img-fluid'/>  
      </div>
    )
  }
}

