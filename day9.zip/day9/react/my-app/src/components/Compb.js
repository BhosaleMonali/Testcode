import React from 'react'
import Compc from './Compc'
export default function Compb(props) {
  return (
    <div>
<h1> Comp B</h1>
        <hr/>
   <Compc p2={props.p1} />
    </div>
  )
}
