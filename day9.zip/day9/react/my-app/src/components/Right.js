import React from 'react'
import { useSelector } from 'react-redux'

export default function Right(props) {
    const categoryName=useSelector((state)=>state.category.value);
   
  return (
 
  
  <div className='border border-1 p-3'>
  <p>Data from Left Component:{props.p2}</p>
  <p>Data from Redux Store :{categoryName}</p>
</div>
  )
}
