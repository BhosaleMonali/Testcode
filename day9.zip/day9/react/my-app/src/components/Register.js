import React from 'react'

export default function Register() {
  return (
    <div className='container'>
        <h1>Register us</h1>
        <p>
            lorem dummy printing

        </p>

    </div>
  )
}
