import React from "react";
import Product from "./Product";
import Login from "./Login";
import M1 from "./M1";
import M2 from "./M2";


// functional components also calles stateless
function Home() {
    return (
        <div class="container text-center">
            <div class="row">


                <div class="col">
                <h2>column1</h2>
                    <Product name="Tshirt" price="1000" path="https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/x/l/0/s-62-meow-tarshi-original-imagt3t6qnb88u5y.jpeg?q=70" />
                </div>
                <div class="col" >
                <h2>column2</h2>
                    <Product name="Tshirt" price="2000" path="https://rukminim2.flixcart.com/image/612/612/k7dnonk0/t-shirt/q/w/m/m-10968502-roadster-original-imafpmj4fyh6fq2j.jpeg?q=70" />
                </div>
                <div class="col">
                <h3>Event Handling</h3>
                    <Login/>
                   
                </div>
                <div class="col">
                    <h2>column4</h2>
                    
                </div>


            </div>
            <div class="row">
            <div className="col-3">
                <M1 name="ameya" age="20"/>

            </div>

            <div className="col-3">
                <M2 name="Monali" age="22"/>
            </div>
            </div>
        </div>
    )

}
export default Home;