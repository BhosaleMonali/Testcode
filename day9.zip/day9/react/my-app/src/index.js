//creating object to access this libary which is inside node module folder

import React from 'react';
import ReactDOM from 'react-dom';
import Home from './components/Home';
import App from './components/App';

import About from './components/About';
import Contact from './components/Contact';
import Register from './components/Register';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.bundle.js'
import Compa from './components/Compa';
import Comp10 from './components/Comp10';
import  Statelift from './components/Statelift'
import { Provider } from 'react-redux'
import customestore from './redux/customestore';

import {
    createBrowserRouter,
    RouterProvider,
  } from "react-router-dom";


  //http://localhost:3000//==>Home
  //http://localhost:3000/aboutus/==>About us
  //http://localhost:3000/contactus/==>
  //http://localhost:3000/newuser/==>
const  routerExample= createBrowserRouter([{
    path:"/",
    element:<App/>,
    children:[
        {path:"",element:<Home /> },
        {path:"aboutus",element:<About/> },
        {path:"contactus",element:<Contact/> },
        {path:"newuser",element:<Register/> },
        {path:"props-drillling",element:<Compa/>},
        {path:"err-boundary",element:<Comp10/>},
        {path:"statelift",element:<Statelift/>}
    ]
}]);



// console.log(typeof React); 
// console.log(typeof ReactDOM); 
const root=ReactDOM.createRoot(document.getElementById('root'));
// root.render('Hello World!!');
// JSX SYNTAX extension to javascript
// var username='React Technology';
// var userage = 30;
// root.render(<h1>hello,{username} age : {userage}</h1>)
// root.render(<p>loerem</p>);
// root.render(<App/>);
root.render(
    <Provider store={customestore}>
<RouterProvider router={routerExample}>
    </RouterProvider>
    </Provider>
    );